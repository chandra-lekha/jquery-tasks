var rows = 5;
var columns = 5;
var j=0;
var k=0;
var $row = $("<div />", {class: 'row'});
var $square = $("<div  />", {class: 'square'});

$(document).ready(function(){
    for(var i = 0; i < rows; i++){      
            $("#wrapper").append($row.clone());
    }

    for(var i = 0; i < columns; i++){
            $(".row").append($square.clone());
    }
     

    $(".square").click(function()
    {    
    	
         k=$(".square").index(this);
    	$(this).text(k);
    	$(this).css( "background-color", "red" );
    	
    }
    )
    {


    }
});